{{/*
StatefulSet template
*/}}
{{- define "hwl.statefulset" -}}
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: {{ include "hwl.fullname" . }}
  labels:
    {{- include "hwl.labels" . | nindent 4 }}
spec:
  replicas: {{ .Values.replicaCount }}
  selector:
    matchLabels:
      {{- include "hwl.selectorLabels" . | nindent 6 }}
  serviceName: {{ include "hwl.fullname" . }}-headless
  template:
    metadata:
      labels:
        {{- include "hwl.selectorLabels" . | nindent 8 }}
        {{- with .Values.podLabels }}
        {{- toYaml . | nindent 8 }}
        {{- end }}
      annotations:
        kubectl.kubernetes.io/default-container: {{ .Chart.Name }}
        {{- with .Values.podAnnotations }}
        {{- toYaml . | nindent 8 }}
        {{- end }}
    spec:
      {{- include "hwl.pod" . | nindent 6 }}
  {{- if .Values.persistence.enabled }}
  volumeClaimTemplates:
    - metadata:
        name: storage
      spec:
        accessModes: {{ .Values.persistence.accessModes }}
        storageClassName: {{ .Values.persistence.storageClassName }}
        resources:
          requests:
            storage: {{ .Values.persistence.size }}
      {{- with .Values.persistence.selectorLabels }}
        selector:
          matchLabels:
          {{- toYaml . | nindent 10 }}
      {{- end }}
  {{- end }}
{{- end }}
